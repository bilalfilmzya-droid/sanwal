package com.sanwal.app;

import android.accessibilityservice.AccessibilityService;
import android.view.accessibility.AccessibilityEvent;

public class SanwalAccessibilityService extends AccessibilityService {

    public static SanwalAccessibilityService instance;

    @Override
    public void onServiceConnected() {
        instance = this;
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {}

    @Override
    public void onInterrupt() {}

    public void showPowerDialog() {
        performGlobalAction(GLOBAL_ACTION_POWER_DIALOG);
    }
}
