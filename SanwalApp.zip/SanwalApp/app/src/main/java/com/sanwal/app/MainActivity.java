package com.sanwal.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.media.AudioManager;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends Activity {

    AudioManager audioManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        audioManager = (AudioManager) getSystemService(AUDIO_SERVICE);

        // Power Button
        Button powerBtn = findViewById(R.id.btnPower);
        powerBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (SanwalAccessibilityService.instance != null) {
                    SanwalAccessibilityService.instance.showPowerDialog();
                } else {
                    // Ask user to enable accessibility
                    new AlertDialog.Builder(MainActivity.this)
                        .setTitle("Permission Chahiye!")
                        .setMessage("Power button kaam karne ke liye Accessibility Service ON karni hogi.\n\nSettings > Accessibility > Sanwal > ON karo")
                        .setPositiveButton("Settings Kholein", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                Intent intent = new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS);
                                startActivity(intent);
                            }
                        })
                        .setNegativeButton("Cancel", null)
                        .show();
                }
            }
        });

        // Volume UP
        Button volUpBtn = findViewById(R.id.btnVolUp);
        volUpBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                audioManager.adjustStreamVolume(
                    AudioManager.STREAM_MUSIC,
                    AudioManager.ADJUST_RAISE,
                    AudioManager.FLAG_SHOW_UI
                );
            }
        });

        // Volume DOWN
        Button volDownBtn = findViewById(R.id.btnVolDown);
        volDownBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                audioManager.adjustStreamVolume(
                    AudioManager.STREAM_MUSIC,
                    AudioManager.ADJUST_LOWER,
                    AudioManager.FLAG_SHOW_UI
                );
            }
        });
    }
}
